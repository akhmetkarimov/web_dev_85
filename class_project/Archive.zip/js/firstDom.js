// Document object model

let element = document.getElementById('top_notch')

console.log(element)
console.log(element.innerText)

// element.innerText = 'Changed text from javascript DOM <a>Link</a>'
// element.innerHTML = 'Changed text from javascript DOM <a href="https://decode.kz">Link</a>'

console.log(element.innerText)

// let service_items = document.getElementsByClassName('service_item')

// console.log(service_items)

// for (let item of service_items){
//     console.log(item)
//     // item.style.background = 'lightblue'
//     item.style.cssText = 'background: lightblue; text-align: left;'
// }




// function changeBackground(e) {
//     console.log(e.target)

//     e.target.style.background = 'lightblue'
//     e.target.innerText = '123'
// }

// let service_items = document.getElementsByClassName('service_item')
// for (let item of service_items){
//     item.addEventListener('click', function(){
//         this.style.background = 'lightblue'
//     })
// }   

